# Vascular Dementia (VaD) Drugs Market Dataset

This repository contains a structured dataset for the **Vascular Dementia (VaD) Drugs Market – Report Code 3552**, generated using publicly accessible information from NextMSC.

## 📁 Included Files
- `summary.json` – Basic market info  
- `segmentation.json` – Market segmentation  
- `companies.csv` – Major key players  
- `market_insights.json` – Drivers, restraints, opportunities  
- `toc.txt` – Table of contents  

## 📌 Purpose
This dataset is intended for:
- Research
- Market analysis
- Educational use
- Machine learning preprocessing

## ⚠ Disclaimer
This dataset is based solely on landing‑page‑level public information. No proprietary or paid data is included.

